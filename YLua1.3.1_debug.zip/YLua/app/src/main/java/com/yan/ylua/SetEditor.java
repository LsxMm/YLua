package com.yan.ylua;

import android.animation.Animator;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.yan.ylua.Scheme.ColorAdapter;
import com.yan.ylua.Tools.YanDialog;
import com.jaredrummler.android.colorpicker.ColorPickerDialog;
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener;
import com.jaredrummler.android.colorpicker.ColorShape;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SetEditor extends AppCompatActivity {
  LinearLayout SchemeClick, colorid, showcolor;
  TextView Scheme;
  ListView colorlist;
  List<String> type;
  List<Integer> color;
  List<String> colorSchemeStrings =
      Arrays.asList(
          "FUNCTION_NAME",
          "IDENTIFIER_VAR",
          "LINE_NUMBER_BACKGROUND",
          "LINE_NUMBER",
          "LINE_DIVIDER",
          "WHOLE_BACKGROUND",
          "TEXT_NORMAL",
          "KEYWORD",
          "LINE_NUMBER_CURRENT",
          "CURRENT_LINE",
          "BLOCK_LINE_CURRENT",
          "BLOCK_LINE",
          "HIGHLIGHTED_DELIMITERS_FOREGROUND",
          "SIDE_BLOCK_LINE");

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.seteditor);
    type = new ArrayList<>();
    color = new ArrayList<>();
    final String[] item = new String[] {"浅色", "深色"};
    SharedPreferences sps = getSharedPreferences("EditorSet", Context.MODE_PRIVATE);
    SharedPreferences.Editor ed = sps.edit();
    type.add("函数名颜色");
    color.add(sps.getInt(colorSchemeStrings.get(0), 0xFFF9A633));
    type.add("索引对象颜色");
    color.add(sps.getInt(colorSchemeStrings.get(1), 0xFFF9A633));
    type.add("行号背景颜色");
    color.add(sps.getInt(colorSchemeStrings.get(2), 0xFF292424));
    type.add("行号颜色");
    color.add(sps.getInt(colorSchemeStrings.get(3), 0xFFFFFFFF));
    type.add("行号分搁线颜色");
    color.add(sps.getInt(colorSchemeStrings.get(4), 0xFFFFFFFF));
    type.add("编辑器背景颜色");
    color.add(sps.getInt(colorSchemeStrings.get(5), 0xFF292424));
    type.add("普通文本颜色");
    color.add(sps.getInt(colorSchemeStrings.get(6), 0xffffffff));
    type.add("关键字颜色");
    color.add(sps.getInt(colorSchemeStrings.get(7), 0xFFF86363));
    type.add("当前行号颜色");
    color.add(sps.getInt(colorSchemeStrings.get(8), 0xFFFfffff));
    type.add("当前行颜色");
    color.add(sps.getInt(colorSchemeStrings.get(9), 0x1E888888));
    type.add("当前代码块线颜色");
    color.add(sps.getInt(colorSchemeStrings.get(10), 0xff000000));
    type.add("代码块线颜色");
    color.add(sps.getInt(colorSchemeStrings.get(11), 0xff000000));
    type.add("突出显示的分隔符前景色");
    color.add(sps.getInt(colorSchemeStrings.get(12), 0xf5f5f5f5));
    SchemeClick = findViewById(R.id.SchemeClick);
    Scheme = findViewById(R.id.Scheme);
    colorid = findViewById(R.id.colorid);
    showcolor = findViewById(R.id.showcolor);
    colorlist = findViewById(R.id.color_list);
    showcolor.setVisibility(View.GONE);
    ColorAdapter adapter = new ColorAdapter(this, type, color);
    colorlist.setAdapter(adapter);
    adapter.setOnItemClickListener(
        new ColorAdapter.OnItemClickListener() {
          @Override
          public void OnItemClick(String type, int position) {
            ColorPickerDialog.Builder build = ColorPickerDialog.newBuilder();
            build
                .setDialogType(ColorPickerDialog.TYPE_CUSTOM)
                .setColorShape(ColorShape.CIRCLE)
                .setAllowPresets(true)
                .setAllowCustom(true)
                .setShowAlphaSlider(true)
                .setShowColorShades(true)
                .setColor(color.get(position));
            ColorPickerDialog dialog = build.create();
            dialog.show(getSupportFragmentManager(), "colorPicker");
            dialog.setColorPickerDialogListener(
                new ColorPickerDialogListener() {
                  @Override
                  public void onColorSelected(int dialogId, int color) {
                    ed.putInt(colorSchemeStrings.get(position), color);
                    ed.commit();
                    adapter.setPosition(position, color);
                  }

                  @Override
                  public void onDialogDismissed(int dialogId) {}
                });
          }
        });
    Scheme.setText(item[sps.getInt("Scheme", 0)]);
    SchemeClick.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View arg0) {

            int choice = 0;

            if ((sps.getInt("Scheme", -1)) != -1) {
              choice = sps.getInt("Scheme", -1);
            }
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SetEditor.this);
            alertDialogBuilder
                .setTitle("请选择主题")
                .setSingleChoiceItems(
                    item,
                    choice,
                    new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                        // 处理选项点击事件
                        ed.putInt("Scheme", which);
                        ed.commit();
                        Scheme.setText(item[which]);
                        YanDialog.show(SetEditor.this, "", "重启后更新");
                        dialog.dismiss();
                      }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
          }
        });
    colorid.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View arg0) {
            if (showcolor.getVisibility() == View.VISIBLE) {
              showcolor.animate()
                    .alpha(0f)
                    .translationY(-colorid.getHeight()) // 动画结束时回到自身上方的位置
                    .setDuration(300)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            showcolor.setVisibility(View.GONE);
                        }
                    });

              // showcolor.setVisibility(View.GONE);

            } else if (showcolor.getVisibility() == View.GONE) {
              showcolor.setTranslationY(-colorid.getHeight());
              showcolor
                  .animate()
                  .translationY(0) // 向下移动视图直到完全展开
                  .alpha(1) // 淡入效果
                  .setDuration(300) // 动画持续时间
                  .setListener(null) // 可以设置动画监听器，这里不需要
                  .start();
              showcolor.setVisibility(View.VISIBLE);
            }
          }
        });
  }
}
