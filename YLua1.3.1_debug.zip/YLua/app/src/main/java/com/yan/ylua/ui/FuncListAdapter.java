package com.yan.ylua.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.yan.ylua.R;
import java.util.List;

public class FuncListAdapter extends BaseAdapter {
    private Context mContext;
    private List<Integer> mTopTexts;
    private List<String> mPath;
    private OnItemClickListener mListener;
    private OnItemLongClickListener mLongListener;

    public FuncListAdapter(Context context, List<Integer> topTexts, List<String> path) {
        mContext = context;
        mTopTexts = topTexts;
        mPath = path;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        mLongListener = listener;
    }

    @Override
    public int getCount() {
        return mTopTexts.size();
    }

    @Override
    public Object getItem(int position) {
        return mPath.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.openlua_filelist, parent, false);
            holder = new ViewHolder();
            holder.topTextView = convertView.findViewById(R.id.topTextView);
            holder.image = convertView.findViewById(R.id.image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.topTextView.setText(mPath.get(position));

        // 根据SharedPreferences设置文本颜色和图片资源
        SharedPreferences sps = mContext.getSharedPreferences("EditorSet", Context.MODE_PRIVATE);
        int scheme = sps.getInt("Scheme", 0);
        int textColor;
        int imageResource;
        if (scheme == 0) {
            imageResource = R.drawable.ic_function_variant;
            textColor = Color.BLACK;
        } else {
            imageResource = R.drawable.ic_function_variant_white;
            textColor = Color.WHITE;
        }
        holder.image.setImageResource(imageResource);
        holder.topTextView.setTextColor(textColor);

        // 设置点击效果
        final int finalPosition = mTopTexts.get(position);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onItemClick(finalPosition);
                }
            }
        });

        // 设置长按事件
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (mLongListener != null) {
                    mLongListener.onItemLongClick(finalPosition, v);
                    return true;
                }
                return false;
            }
        });

        return convertView;
    }

    public class ViewHolder {
        TextView topTextView;
        ImageView image;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(int position, View v);
    }
}
