package com.yan.ylua;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.os.Bundle;
import android.os.Build;
import android.view.Window;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.yan.ylua.Scheme.YluaScheme;
import com.yan.ylua.LuaLanguage.LuaLanguage;
import com.yan.ylua.Tools.YanDialog;
import io.github.rosemoe.sora.event.ContentChangeEvent;
import io.github.rosemoe.sora.widget.CodeEditor;
import io.github.rosemoe.sora.widget.SymbolInputView;
import io.github.rosemoe.sora.widget.schemes.EditorColorScheme;

public class CodeTestActivity extends AppCompatActivity {
  CodeEditor edit;
  MaterialToolbar toolbar;
  SymbolInputView sym;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_code_test);
    edit = findViewById(R.id.activity_mainio_github_rosemoe_sora_widget_CodeEditor2);
    sym = findViewById(R.id.symbol_input2);
    String[] symbols =
        new String[] {
          "->", "Fun", "{", "}", "(", ")", ",", ".", ";", "\"", "?", "+", "-", "*", "/", "=", "'",
          "[", "]", ":"
        };
    String[] equivalents =
        new String[] {
          "\t",
          "function",
          "{}",
          "}",
          "()",
          ")",
          ",",
          ".",
          ";",
          "\"",
          "?",
          "+",
          "-",
          "*",
          "/",
          "=",
          "'",
          "[]",
          "]",
          ":"
        };
    sym.addSymbols(symbols, equivalents);
    sym.setBackgroundColor(0xff1b1b1b);
    sym.setTextColor(0xffffffff);
    sym.bindEditor(edit);
    edit.setColorScheme(s_scheme());
    LuaLanguage language = new LuaLanguage();
    edit.setEditorLanguage(language);
    /*edit.subscribeEvent(
        ContentChangeEvent.class,
        (event, unsubscribe) -> {
          edit.invalidate();
        });*/
    edit.setNonPrintablePaintingFlags(
        CodeEditor.FLAG_DRAW_WHITESPACE_LEADING
            | CodeEditor.FLAG_DRAW_LINE_SEPARATOR
            | CodeEditor.FLAG_DRAW_WHITESPACE_IN_SELECTION);
    edit.setWordwrap(true);
    edit.setBlockLineEnabled(true);
    YanDialog.show(this, "", edit.getDiagnostics() + "");
    toolbar = findViewById(R.id.test_toolbar);
    setSupportActionBar(toolbar);
    toolbar.setTitle("Lua Test Activity");
    toolbar.setSubtitle("By Yry Lua Script Test Editor");
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      Window window = getWindow();
      window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
      window.setStatusBarColor(0xff1b1b1b);
    }
    Intent intent = getIntent();
    String code = intent.getStringExtra("code");
    edit.setText(code);
  }

  public YluaScheme s_scheme() {
    YluaScheme scheme = new YluaScheme();
    SharedPreferences sps = getSharedPreferences("EditorSet", Context.MODE_PRIVATE);
    scheme.setColor(EditorColorScheme.FUNCTION_NAME, sps.getInt("FUNCTION_NAME", 0xFFF9A633));
    scheme.setColor(EditorColorScheme.IDENTIFIER_VAR, sps.getInt("IDENTIFIER_VAR", 0xFFF9A633));
    scheme.setColor(
        EditorColorScheme.LINE_NUMBER_BACKGROUND, sps.getInt("LINE_NUMBER_BACKGROUND", 0xFF292424));
    scheme.setColor(EditorColorScheme.LINE_NUMBER, sps.getInt("LINE_NUMBER", 0xffffffff));
    scheme.setColor(EditorColorScheme.LINE_DIVIDER, sps.getInt("LINE_DIVIDER", 0xffffffff));
    scheme.setColor(EditorColorScheme.WHOLE_BACKGROUND, sps.getInt("WHOLE_BACKGROUND", 0xFF292424));
    scheme.setColor(EditorColorScheme.TEXT_NORMAL, sps.getInt("TEXT_NORMAL", 0xffffffff));
    scheme.setColor(EditorColorScheme.KEYWORD, sps.getInt("KEYWORD", 0xFFF86363));
    scheme.setColor(
        EditorColorScheme.LINE_NUMBER_CURRENT, sps.getInt("LINE_NUMBER_CURRENT", 0xffffffff));
    scheme.setColor(EditorColorScheme.CURRENT_LINE, sps.getInt("CURRENT_LINE", 0x1e888888));
    scheme.setColor(
        EditorColorScheme.BLOCK_LINE_CURRENT, sps.getInt("BLOCK_LINE_CURRENT", 0xFF000000));
    scheme.setColor(EditorColorScheme.BLOCK_LINE, sps.getInt("BLOCK_LINE", 0xFF000000));
    scheme.setColor(
        EditorColorScheme.HIGHLIGHTED_DELIMITERS_FOREGROUND,
        sps.getInt("HIGHLIGHTED_DELIMITERS_FOREGROUND", 0xf5f5f5f5));
    return scheme;
  }
}
