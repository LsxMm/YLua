package com.yan.ylua.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import com.yan.ylua.MainActivity;
import com.yan.ylua.R;
import com.yan.ylua.Tools.YanDialog;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ParingTree extends Fragment {
  public ListView funclist;
  public int ii;
  List<String> funcName;
  List<Integer> funcLine;

  @Override
  public View onCreateView(LayoutInflater arg0, ViewGroup arg1, Bundle arg2) {
    // TODO: Implement this method
    View view = arg0.inflate(R.layout.paringtree, arg1, false);
    funclist = view.findViewById(R.id.func_list);
    // YanDialog.show(getActivity(),"",""+funclist);
    final ExecutorService executor = Executors.newSingleThreadExecutor();
    executor.submit(
        () -> {
          /*ThreadManager.runOnUiThread(
          new Runnable() {
            @Override
            public void run() {*/
          MainActivity activity = (MainActivity) getActivity();
          if (activity != null) {
            funcName = new ArrayList<>();
            funcLine = new ArrayList<>();
            String text = activity.fragments.get(activity.pager_choice).edit.getText().toString();

            // 定义正则表达式，用于匹配函数声明或变量赋值
            String regexFunction = "\\bfunction\\s+(\\w+)\\s*";
            String regexVariable = "\\b(\\w+)\\s*=\\s*function";

            // 编译正则表达式
            Pattern patternFunction = Pattern.compile(regexFunction, Pattern.MULTILINE);
            Pattern patternVariable = Pattern.compile(regexVariable, Pattern.MULTILINE);

            // 查找匹配的函数声明并返回行号
            Matcher matcherFunction = patternFunction.matcher(text);
            while (matcherFunction.find()) {
              String functionName = matcherFunction.group(1);
              int lineNumber = getLineNumber(text, matcherFunction.start());
              funcName.add(functionName + " : " + lineNumber);
              funcLine.add(lineNumber);
            }

            // 查找匹配的变量赋值并返回行号
            Matcher matcherVariable = patternVariable.matcher(text);
            while (matcherVariable.find()) {
              String variableName = matcherVariable.group(1);
              int lineNumber = getLineNumber(text, matcherVariable.start());
              funcName.add(variableName + " : " + lineNumber);
              funcLine.add(lineNumber);
            }
            // YanDialog.show(getActivity(), "", ""+funcName);
            FuncListAdapter adapt = new FuncListAdapter(activity, funcLine, funcName);
            try {
              funclist.setAdapter(adapt);
              adapt.setOnItemClickListener(
                  new FuncListAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(int position) {
                      activity
                          .fragments
                          .get(activity.pager_choice)
                          .edit
                          .setSelection(position - 1, 1);
                    }
                  });
            } catch (Exception e) {
              YanDialog.show(getActivity(), "", e.getMessage());
            }
          }
          // }
          // });
        });

    return view;
  }

  @Override
  @Deprecated
  public void onActivityCreated(Bundle arg0) {
    super.onActivityCreated(arg0);
    // TODO: Implement this method
    MainActivity activity = (MainActivity) getActivity();
    if (activity != null) {
      activity.parsing.setOnClickListener(
          new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
              activity.drawerLayout.openDrawer(GravityCompat.END);
              
              funcName = new ArrayList<>();
              funcLine = new ArrayList<>();
              String text = activity.fragments.get(activity.pager_choice).edit.getText().toString();

              // 定义正则表达式，用于匹配函数声明或变量赋值
              String regexFunction = "\\bfunction\\s+(\\w+)\\s*";
              String regexVariable = "\\b(\\w+)\\s*=\\s*function";

              // 编译正则表达式
              Pattern patternFunction = Pattern.compile(regexFunction, Pattern.MULTILINE);
              Pattern patternVariable = Pattern.compile(regexVariable, Pattern.MULTILINE);

              // 查找匹配的函数声明并返回行号
              Matcher matcherFunction = patternFunction.matcher(text);
              while (matcherFunction.find()) {
                String functionName = matcherFunction.group(1);
                int lineNumber = getLineNumber(text, matcherFunction.start());
                funcName.add(functionName + " : " + lineNumber);
                funcLine.add(lineNumber);
              }

              // 查找匹配的变量赋值并返回行号
              Matcher matcherVariable = patternVariable.matcher(text);
              while (matcherVariable.find()) {
                String variableName = matcherVariable.group(1);
                int lineNumber = getLineNumber(text, matcherVariable.start());
                funcName.add(variableName + " : " + lineNumber);
                funcLine.add(lineNumber);
              }
              // YanDialog.show(getActivity(), "", ""+funcName);
              FuncListAdapter adapt = new FuncListAdapter(activity, funcLine, funcName);
              try {
                funclist.setAdapter(adapt);
                adapt.setOnItemClickListener(
                    new FuncListAdapter.OnItemClickListener() {
                      @Override
                      public void onItemClick(int position) {
                        activity
                            .fragments
                            .get(activity.pager_choice)
                            .edit
                            .setSelection(position - 1, 0);
                      }
                    });
              } catch (Exception e) {
                YanDialog.show(getActivity(), "", e.getMessage());
              }
            }
          });
    }
  }

  private int getLineNumber(String text, int index) {
    int lineNumber = 1;
    int lineStartIndex = 0;
    while (index > lineStartIndex && lineStartIndex < text.length()) {
      if (text.charAt(lineStartIndex) == '\n') {
        lineNumber++;
      }
      lineStartIndex++;
    }
    return lineNumber;
  }
}
