package com.yan.ylua.Scheme;

import android.content.SharedPreferences;
import android.content.Context;
import io.github.rosemoe.sora.text.Content;
import io.github.rosemoe.sora.widget.schemes.EditorColorScheme;

public class YluaScheme extends EditorColorScheme {

  @Override
  public void applyDefault() {
    super.applyDefault();
        setColor(FUNCTION_NAME,0xFFF9A633);
        setColor(IDENTIFIER_VAR,0xFFF9A633);
        setColor(LINE_NUMBER_BACKGROUND,0xFF292424);
        setColor(LINE_NUMBER,0xffffffff);
        setColor(LINE_DIVIDER,0xffffffff);
        setColor(WHOLE_BACKGROUND,0xFF292424);
        setColor(TEXT_NORMAL,0xffffffff);
        setColor(KEYWORD,0xFFF86363);
        setColor(LINE_NUMBER_CURRENT,0xffffffff);
        setColor(CURRENT_LINE,0x1E888888);
        setColor(BLOCK_LINE_CURRENT,0xff000000);
        setColor(BLOCK_LINE,0xff000000);
        setColor(HIGHLIGHTED_DELIMITERS_FOREGROUND,0xf5f5f5f5);
  }
}
