package com.yan.ylua;
import io.github.rosemoe.sora.lang.completion.CompletionHelper;
public class MyPrefixChecker implements CompletionHelper.PrefixChecker {
    @Override
    public boolean check(char ch) {
        // 允许字母、数字和点号作为有效前缀字符
        return Character.isLetterOrDigit(ch) || ch == '.';
    }
}
