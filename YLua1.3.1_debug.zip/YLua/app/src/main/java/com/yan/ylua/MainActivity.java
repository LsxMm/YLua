package com.yan.ylua;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.yan.ylua.Tools.LoadingDialog;
import com.yan.ylua.Tools.ThreadManager;
import com.yan.ylua.Tools.YanDialog;
import com.yan.ylua.Tools.YanToast;
import com.yan.ylua.databinding.ActivityMainBinding;
import com.yan.ylua.format.AutoIndent;
import com.yan.ylua.ui.Code;
import com.yan.ylua.ui.ParingTree;
import io.github.rosemoe.sora.widget.CodeEditor;
import io.github.rosemoe.sora.widget.EditorSearcher.SearchOptions;
import io.github.rosemoe.sora.widget.SelectionMovement;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.PatternSyntaxException;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LoadState;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.compiler.LuaC;
import org.luaj.vm2.lib.BaseLib;
import org.luaj.vm2.lib.Bit32Lib;
import org.luaj.vm2.lib.CoroutineLib;
import org.luaj.vm2.lib.DebugLib;
import org.luaj.vm2.lib.PackageLib;
import org.luaj.vm2.lib.StringLib;
import org.luaj.vm2.lib.TableLib;
import org.luaj.vm2.lib.Utf8Lib;
import org.luaj.vm2.lib.jse.JseIoLib;
import org.luaj.vm2.lib.jse.JseMathLib;
import org.luaj.vm2.lib.jse.JseOsLib;
import org.luaj.vm2.lib.jse.JsePlatform;
import org.luaj.vm2.lib.jse.LuajavaLib;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
  private ActivityMainBinding binding;
  ListView listview;
  public TextView run, redo, undo, menu, save, showTab, thisfilename, parsing, paringtree;
  ViewPager2 viewPager2;
  TabLayout tabLayout;
  public int pager_choice;
  public DrawerLayout drawerLayout;
  List<String> AllPath = new ArrayList<>();
  PopupMenu popo;
  Toolbar toolbar;
  PopupMenu searchMenu;
  SearchOptions searchOptions = new SearchOptions(false, false);
  public final java.util.ArrayList<FileContentFragment> fragments = new java.util.ArrayList<>();
  LinearLayout left_drawer, FileToolBar, search_panel, paringdrawer, paringToolBar;
  Button goto_prev, goto_next, search_options;
  NavigationView NavigationView;
  ParingTree paringt = new ParingTree();
  Code codet = new Code();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      // 检查是否已经拥有所有文件的管理权限
      if (Environment.isExternalStorageManager()) {
        Log.d("Permission", "Already have permission");
      } else {
        // 申请权限
        finish();
        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, 1);
      }
    } else {
      Log.d("Permission", "Not required on this Android version");
      if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
          != PackageManager.PERMISSION_GRANTED) {
        ActivityCompat.requestPermissions(
            this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
      }

      if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
          != PackageManager.PERMISSION_GRANTED) {
        ActivityCompat.requestPermissions(
            this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
      }
    }
    // Inflate and get instance of binding
    binding = ActivityMainBinding.inflate(getLayoutInflater());
    listview = binding.menuList;
    showTab = binding.showTab;
    drawerLayout = binding.drawerLayout;
    thisfilename = binding.thisfilename;
    viewPager2 = binding.viewpager2;
    tabLayout = binding.tablayout;
    menu = binding.menu;
    save = binding.save;
    toolbar = binding.toolbar;
    undo = binding.undo;
    redo = binding.redo;
    run = binding.run;
    left_drawer = binding.leftDrawer;
    FileToolBar = binding.FileToolBar;
    search_panel = binding.searchPanel;
    search_options = binding.searchOptions;
    goto_next = binding.btnGotoNext;
    goto_prev = binding.btnGotoPrev;
    parsing = binding.parsing;
    NavigationView = binding.navView;
    paringdrawer = binding.paringdrawer;
    paringToolBar = binding.paringToolBar;
    paringtree = binding.paringtree;
    menu.setOnClickListener(this);
    showTab.setOnClickListener(this);
    redo.setOnClickListener(this);
    undo.setOnClickListener(this);
    save.setOnClickListener(this);
    run.setOnClickListener(this);
    search_options.setOnClickListener(this);
    goto_prev.setOnClickListener(this);
    goto_next.setOnClickListener(this);
    binding.searchEditor.addTextChangedListener(
        new TextWatcher() {
          @Override
          public void afterTextChanged(Editable arg0) {
            tryCommitSearch();
          }

          @Override
          public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {}

          @Override
          public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {}
        });
    searchMenu = new PopupMenu(MainActivity.this, binding.searchOptions);
    searchMenu.inflate(R.menu.menu_search_options);
    // Update option states
    searchMenu.setOnMenuItemClickListener(
        item -> {
          // Update option states
          item.setChecked(!item.isChecked());
          if (item.isChecked()) {
            // Regex and whole word mode can not be both chose
            int iid = item.getItemId();
            if (iid == R.id.search_option_regex) {
              searchMenu.getMenu().findItem(R.id.search_option_whole_word).setChecked(false);
            } else if (iid == R.id.search_option_whole_word) {
              searchMenu.getMenu().findItem(R.id.search_option_regex).setChecked(false);
            }
          }
          computeSearchOptions();
          tryCommitSearch();
          return true;
        });
    // set content view to binding's root
    setContentView(binding.getRoot());
    // paringt = new ParingTree();
    setList();
    viewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
    viewPager2.setUserInputEnabled(false);
    tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
    SharedPreferences open = getSharedPreferences("EditorSet", Context.MODE_PRIVATE);

    tabLayout.addOnTabSelectedListener(
        new TabLayout.OnTabSelectedListener() {
          @Override
          public void onTabSelected(TabLayout.Tab tab) {
            pager_choice = tab.getPosition();
            SharedPreferences.Editor ed = open.edit();
            ed.putInt("Path", pager_choice);
            ed.commit();
          }

          @Override
          public void onTabUnselected(TabLayout.Tab tab) {}

          @Override
          public void onTabReselected(TabLayout.Tab tab) {
            // Toast.makeText(MainActivity.this, tab.getText().toString(),
            // Toast.LENGTH_SHORT).show();
            // removeTabAndFragment(tab.getText().toString());
            PopupMenu pop = new PopupMenu(MainActivity.this, tab.view);
            Menu men = pop.getMenu();
            men.add(0, 0, 0, "关闭当前");
            men.add(0, 1, 0, "关闭其他");
            men.add(0, 2, 0, "关闭所有");
            pop.setOnMenuItemClickListener(
                new PopupMenu.OnMenuItemClickListener() {
                  @Override
                  public boolean onMenuItemClick(MenuItem arg0) {
                    int id = arg0.getItemId();
                    switch (id) {
                      case 0:
                        removeTabAndFragment(pager_choice);
                        break;
                    }
                    return false;
                  }
                });
            pop.show();
          }
        });
    popo = new PopupMenu(this, menu);
    Menu men = popo.getMenu();
    SharedPreferences sps = getSharedPreferences("EditorSet", Context.MODE_PRIVATE);
    men.add(0, 0, 0, "设置");
    SubMenu func = men.addSubMenu(0, 1, 0, "功能");
    SubMenu sign = men.addSubMenu(0, 2, 0, "光标");
    func.add(1, 0, 0, "自动换行").setCheckable(true).setChecked(sps.getBoolean("Wordwarp", true));
    func.add(1, 1, 0, "显示行号").setCheckable(true).setChecked(sps.getBoolean("linenumber", true));
    func.add(1, 2, 0, "固定行号").setCheckable(true).setChecked(sps.getBoolean("pin", false));
    func.add(1, 3, 0, "搜索文本").setIcon(R.drawable.search);
    func.add(1, 4, 0, "格式化代码").setIcon(R.drawable.format);
    func.add(1, 5, 0, "Test").setIcon(R.drawable.test);
    sign.add(2, 0, 0, "移到最后");
    sign.add(2, 1, 0, "左移");
    sign.add(2, 2, 0, "右移");
    sign.add(2, 3, 0, "上移");
    sign.add(2, 4, 0, "下移");
    sign.add(2, 5, 0, "行首");
    sign.add(2, 6, 0, "行末");
    func.setHeaderTitle("功能");
    sign.setHeaderTitle("光标");
    func.setHeaderIcon(R.drawable.other);
    sign.setHeaderIcon(R.drawable.other);

    popo.setOnMenuItemClickListener(
        new PopupMenu.OnMenuItemClickListener() {
          @Override
          public boolean onMenuItemClick(MenuItem arg0) {
            SharedPreferences.Editor ed = sps.edit();
            int gro = arg0.getGroupId();
            switch (gro) {
              case 0:
                switch (arg0.getItemId()) {
                  case 0:
                    startActivity(new Intent(MainActivity.this, SetEditor.class));
                    break;
                }
                break;
              case 1:
                int id = arg0.getItemId();
                switch (id) {
                  case 0:
                    ed.putBoolean("Wordwarp", (!arg0.isChecked()));
                    ed.commit();
                    for (int i = 0; i <= fragments.size() - 1; ++i) {
                      fragments.get(i).edit.setWordwrap(!arg0.isChecked());
                    }
                    arg0.setChecked(!arg0.isChecked());
                    break;
                  case 1:
                    ed.putBoolean("linenumber", (!arg0.isChecked()));
                    ed.commit();
                    for (int i = 0; i <= fragments.size() - 1; ++i) {
                      fragments.get(i).edit.setLineNumberEnabled(!arg0.isChecked());
                    }
                    arg0.setChecked(!arg0.isChecked());
                    break;
                  case 2:
                    ed.putBoolean("pin", (!arg0.isChecked()));
                    ed.commit();
                    for (int i = 0; i <= fragments.size() - 1; ++i) {
                      fragments.get(i).edit.setPinLineNumber(!arg0.isChecked());
                    }
                    arg0.setChecked(!arg0.isChecked());
                    break;
                  case 3:
                    search_panel.setVisibility(View.VISIBLE);
                    break;
                  case 4:
                    ThreadManager.runOnUiThread(
                        new Runnable() {
                          @Override
                          public void run() {
                            String str = fragments.get(pager_choice).edit.getText().toString();
                            fragments.get(pager_choice).edit.selectAll();
                            fragments.get(pager_choice).edit.deleteText();
                            fragments
                                .get(pager_choice)
                                .edit
                                .commitText(AutoIndent.format(str, 4).toString());
                          }
                        });
                    break;
                  case 5:
                    Intent testactivity = new Intent(MainActivity.this, CodeTestActivity.class);
                    testactivity.putExtra(
                        "code", fragments.get(pager_choice).edit.getText().toString());
                    startActivity(testactivity);
                    break;
                }
                break;
              case 2:
                int id2 = arg0.getItemId();
                CodeEditor edit = fragments.get(pager_choice).edit;
                switch (id2) {
                  case 0:
                    edit.setSelection(
                        edit.getText().getLineCount() - 1,
                        edit.getText().getColumnCount(edit.getText().getLineCount() - 1));
                    break;
                  case 1:
                    edit.moveSelection(SelectionMovement.LEFT);
                    break;
                  case 2:
                    edit.moveSelection(SelectionMovement.RIGHT);
                    break;
                  case 3:
                    edit.moveSelection(SelectionMovement.UP);
                    break;
                  case 4:
                    edit.moveSelection(SelectionMovement.DOWN);
                    break;
                  case 5:
                    edit.moveSelection(SelectionMovement.LINE_START);
                    break;
                  case 6:
                    edit.moveSelection(SelectionMovement.LINE_END);
                    break;
                }
                break;
            }
            return false;
          }
        });
    int OpenPath = open.getInt("Path", -1);

    List<String> OpenList = getList("OpenList");
    if (OpenList.size() > 0) {
      for (String k : OpenList) {
        addFileToUI(k);
      }
    }
    if (OpenPath != -1) {
      viewPager2.setCurrentItem(OpenPath);
    }
    try {
      if (!new File("/sdcard/Ylua/").exists()) {
        new File("/sdcard/Ylua/").mkdirs();
        FileWriter frist = new FileWriter("/sdcard/Ylua/第一行代码.lua");
        BufferedWriter write = new BufferedWriter(frist);
        write.write("print(\"Hello Word\")");
        write.close();
        addFileToUI("/sdcard/Ylua/第一行代码.lua");
        if (new File("/sdcard/Ylua/").isDirectory()) {
          SharedPreferences spe = getSharedPreferences("OpenPath", MODE_PRIVATE);
          SharedPreferences.Editor editor = spe.edit();
          editor.putString("/sdcard/Ylua/第一行代码.lua", "/sdcard/Ylua/第一行代码.lua");
          editor.commit();
          Toast.makeText(MainActivity.this, "文件夹创建成功", Toast.LENGTH_SHORT).show();
        } else {
          Toast.makeText(MainActivity.this, "文件夹创建失败", Toast.LENGTH_SHORT).show();
        }
      }
    } catch (Exception e) {
      System.out.println(e.toString());
    }
    int Scheme = open.getInt("Scheme", 0);
    switch (Scheme) {
      case 1:
        GradientDrawable back_dark = new GradientDrawable();
        back_dark.setColor(0xff292424);
        back_dark.setCornerRadius(50);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
          Window window = getWindow();
          window.addFlags(
              android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
          window.setStatusBarColor(0xff1b1b1b);
        }
        toolbar.setBackgroundColor(0xff1b1b1b);
        tabLayout.setBackgroundColor(0xff1b1b1b);
        tabLayout.setTabTextColors(0xffffffff, 0xFF77E4AD);
        undo.setBackgroundResource(R.drawable.ic_openlua_white_undo);
        redo.setBackgroundResource(R.drawable.ic_openlua_white_redo);
        run.setBackgroundResource(R.drawable.run_white);
        save.setBackgroundResource(R.drawable.ic_openlua_folder_white_cog);
        menu.setBackgroundResource(R.drawable.ic_openlua_white_menu);
        showTab.setBackgroundResource(R.drawable.ic_openlua_white_tab);
        parsing.setBackgroundResource(R.drawable.ic_parsing_white);
        left_drawer.setBackgroundResource(R.drawable.mdark);
        FileToolBar.setBackgroundDrawable(back_dark);
        thisfilename.setTextColor(0xffffffff);
        paringdrawer.setBackgroundResource(R.drawable.mdark);
        paringToolBar.setBackgroundDrawable(back_dark);
        paringtree.setTextColor(0xffffffff);
        NavigationView.setBackgroundResource(R.drawable.malert_dark);
        break;
      case 0:
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
          Window window = getWindow();
          window.addFlags(
              android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
          window.setStatusBarColor(ContextCompat.getColor(this, android.R.color.background_light));
        }
        GradientDrawable back = new GradientDrawable();
        back.setColor(Color.WHITE);
        back.setCornerRadius(50);
        toolbar.setBackgroundColor(0xffffffff);
        tabLayout.setBackgroundColor(0xffffffff);
        tabLayout.setTabTextColors(0xff000000, 0xFF77E4AD);
        undo.setBackgroundResource(R.drawable.ic_openlua_undo);
        redo.setBackgroundResource(R.drawable.ic_openlua_redo);
        run.setBackgroundResource(R.drawable.run_dark);
        save.setBackgroundResource(R.drawable.ic_openlua_folder_cog);
        menu.setBackgroundResource(R.drawable.ic_openlua_menu);
        showTab.setBackgroundResource(R.drawable.ic_openlua_tab);
        parsing.setBackgroundResource(R.drawable.ic_parsing);
        // left_drawer.setBackgroundColor(0xf5f5f5f5);
        left_drawer.setBackgroundResource(R.drawable.malert);
        FileToolBar.setBackgroundDrawable(back);
        thisfilename.setTextColor(0xff000000);
        // paringdrawer.setBackgroundColor(0xffffffff);
        paringdrawer.setBackgroundResource(R.drawable.malert);
        paringToolBar.setBackgroundDrawable(back);
        paringtree.setTextColor(0xff000000);
        NavigationView.setBackgroundResource(R.drawable.malert);
        break;
    }
    NavigationView.getMenu().findItem(R.id.paring).setChecked(true);
    setupDrawerContent(NavigationView);
    displayFragment(new ParingTree());

    // edit.getSearcher().search()

  }

  private static int getLineNumber(String text, int index) {
    int lineNumber = 1;
    int lineStartIndex = 0;
    while (index > lineStartIndex && lineStartIndex < text.length()) {
      if (text.charAt(lineStartIndex) == '\n') {
        lineNumber++;
      }
      lineStartIndex++;
    }
    return lineNumber;
  }

  File currentDirectory = new File("/sdcard/");

  public void setList() {
    final List<String> fileNames = new ArrayList<>();
    final List<String> filePaths = new ArrayList<>();
    listFiles(currentDirectory, fileNames, filePaths);
    thisfilename.setText(currentDirectory.getPath());
    // 将文件名和文件路径转换为File对象列表
    List<File> files = new ArrayList<>();
    for (String path : filePaths) {
      files.add(new File(path));
    }

    // 自定义比较器，确保文件夹在文件之前
    Comparator<File> customComparator =
        (file1, file2) -> {
          boolean isDir1 = file1.isDirectory();
          boolean isDir2 = file2.isDirectory();

          // 如果两个都是文件夹或都是文件，按名称排序
          if (isDir1 == isDir2) {
            return file1.getName().compareToIgnoreCase(file2.getName());
          }

          // 如果一个是文件夹，另一个是文件，则文件夹排在前面
          return isDir1 ? -1 : 1;
        };

    // 对File对象列表进行排序
    Collections.sort(files, customComparator);

    // 将排序后的File对象列表转回String列表
    List<String> sortedFileNames = new ArrayList<>();
    List<String> sortedFilePaths = new ArrayList<>();
    sortedFileNames.add("...");
    sortedFilePaths.add("...");
    for (File file : files) {
      sortedFileNames.add(file.getName());
      sortedFilePaths.add(file.getPath());
    }
    FileListAdapter adapter =
        new FileListAdapter(MainActivity.this, sortedFileNames, sortedFilePaths);
    adapter.setOnItemClickListener(
        new FileListAdapter.OnItemClickListener() {
          @Override
          public void onItemClick(String topText, int position) {
            if (position == 0) {
              if (!currentDirectory.equals(Environment.getExternalStorageDirectory())) {
                currentDirectory = currentDirectory.getParentFile();
                setList(); // 递归显示文件选择对话框
              }

            } else {
              String selectedFileName = sortedFileNames.get(position);
              String selectedFilePath = sortedFilePaths.get(position);
              File selectedFile = new File(selectedFilePath);
              if (selectedFile.isDirectory()) {
                // 如果是文件夹，则进入文件夹
                currentDirectory = selectedFile;
                setList(); // 递归显示文件选择对话框
              } else {
                // 如果是文件，则处理文件的逻辑，例如打开文件等
                addFileToUI(selectedFilePath);
                drawerLayout.close();
              }
            }
          }
        });
    adapter.setOnItemLongClickListener(
        new FileListAdapter.OnItemLongClickListener() {
          @Override
          public void onItemLongClick(String topText, int position, View v) {
            PopupMenu pop = new PopupMenu(MainActivity.this, v);
            Menu men = pop.getMenu();
            File bool = new File(sortedFilePaths.get(position));
            if (bool.isDirectory()) {
              men.add(0, 0, 0, "新建文件夹");
              men.add(0, 1, 0, "删除文件夹");
              men.add(0, 2, 0, "重命名文件夹");
              pop.setOnMenuItemClickListener(
                  new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem arg0) {
                      int id = arg0.getItemId();
                      switch (id) {
                        case 0:
                          showCustomDialog(MainActivity.this, thisfilename.getText().toString(), 2);
                          break;
                        case 1:
                          LoadingDialog loadingDialog =
                              new LoadingDialog.Builder(MainActivity.this)
                                  .setMessage("正在加载...")
                                  .create();
                          loadingDialog.show();

                          // 创建一个新线程执行删除操作
                          new Thread(
                                  new Runnable() {
                                    @Override
                                    public void run() {
                                      deleteDirectory(bool);
                                      // 删除操作完成后，在主线程中执行弹窗消失和设置列表操作
                                      ThreadManager.runOnUiThread(
                                          new Runnable() {
                                            @Override
                                            public void run() {
                                              loadingDialog.dismiss();
                                              setList();
                                              YanDialog.show(MainActivity.this, "", "success!");
                                            }
                                          });
                                    }
                                  })
                              .start();

                          break;
                        case 2:
                          LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                          View dialogView = inflater.inflate(R.layout.custom_dialog_layout, null);

                          // 获取编辑框
                          final EditText editText = dialogView.findViewById(R.id.edit_text);

                          // 创建提示框
                          AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                          builder.setTitle("Text");
                          builder.setView(dialogView);
                          builder.setPositiveButton(
                              "确定",
                              new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                  // 在这里处理用户点击确定按钮的逻辑
                                  String inputText = editText.getText().toString();
                                  try {
                                    LoadingDialog loadingDialog =
                                        new LoadingDialog.Builder(MainActivity.this)
                                            .setMessage("正在加载...")
                                            .create();
                                    loadingDialog.show();
                                    new Thread(
                                            new Runnable() {
                                              @Override
                                              public void run() {

                                                boolean bo = renameDirectory(bool, inputText);
                                                ThreadManager.runOnUiThread(
                                                    new Runnable() {
                                                      @Override
                                                      public void run() {
                                                        loadingDialog.dismiss();
                                                        setList();
                                                        if (bo) {
                                                          YanDialog.show(
                                                              MainActivity.this, "", "success!");
                                                        } else {
                                                          YanDialog.show(
                                                              MainActivity.this, "", "Error");
                                                        }
                                                      }
                                                    });
                                              }
                                            })
                                        .start();

                                  } catch (Exception e) {
                                    YanDialog.show(MainActivity.this, "error", e.getMessage());
                                  }

                                  ;
                                }
                              });
                          builder.setNegativeButton(
                              "取消",
                              new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                  dialog.dismiss();
                                }
                              });

                          AlertDialog dialog = builder.create();
                          dialog.show();

                          break;
                      }
                      return false;
                    }
                  });
            } else {
              men.add(0, 0, 0, "新建文件");
              men.add(0, 1, 0, "删除文件");
              men.add(0, 2, 0, "重命名文件");
            }

            pop.show();
          }
        });
    listview.setAdapter(adapter);
  }

  private void computeSearchOptions() {
    MenuItem matchCaseItem = searchMenu.getMenu().findItem(R.id.search_option_match_case);
    boolean caseInsensitive = matchCaseItem.isChecked();

    int type = SearchOptions.TYPE_NORMAL;
    MenuItem regexItem = searchMenu.getMenu().findItem(R.id.search_option_regex);
    boolean regex = regexItem.isChecked();
    if (regex) {
      type = SearchOptions.TYPE_REGULAR_EXPRESSION;
    }

    MenuItem wholeWordItem = searchMenu.getMenu().findItem(R.id.search_option_whole_word);
    boolean wholeWord = wholeWordItem.isChecked();
    if (wholeWord) {
      type = SearchOptions.TYPE_WHOLE_WORD;
    }
    MenuItem close = searchMenu.getMenu().findItem(R.id.search_option_close);
    close.setOnMenuItemClickListener(
        new MenuItem.OnMenuItemClickListener() {
          @Override
          public boolean onMenuItemClick(MenuItem arg0) {
            if (arg0.getItemId() == R.id.search_option_close) {
              search_panel.setVisibility(View.GONE);
            }
            return false;
          }
        });
    searchOptions = new SearchOptions(type, caseInsensitive);
  }

  private void tryCommitSearch() {
    Editable query = binding.searchEditor.getEditableText();
    if (query.length() > 0) {
      try {
        fragments.get(pager_choice).edit.getSearcher().search(query.toString(), searchOptions);
      } catch (PatternSyntaxException e) {
        // Regex error
      }
    } else {
      fragments.get(pager_choice).edit.getSearcher().stopSearch();
    }
  }

  public void gotoNext() {
    try {
      fragments.get(pager_choice).edit.getSearcher().gotoNext();
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void gotoPrev() {
    try {
      fragments.get(pager_choice).edit.getSearcher().gotoPrevious();
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void replace(View view) {
    try {
      fragments
          .get(pager_choice)
          .edit
          .getSearcher()
          .replaceThis(binding.replaceEditor.getText().toString());
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void replaceAll(View view) {
    try {
      fragments
          .get(pager_choice)
          .edit
          .getSearcher()
          .replaceAll(binding.replaceEditor.getText().toString());
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  private void setupDrawerContent(NavigationView navigationView) {
    navigationView.setNavigationItemSelectedListener(
        item -> {
          Fragment fragment = null;
          int iid = item.getItemId();
          if (iid == R.id.paring) {
            fragment = paringt;
          } else if (iid == R.id.nav_profile) {
            fragment = codet;
          }

          if (fragment != null) {
            // 检查是否已经选中
            if (!navigationView.getMenu().findItem(iid).isChecked()) {
              displayFragment(fragment);
              navigationView.getMenu().findItem(item.getItemId()).setChecked(true);
              return true;
            }
          }
          return false;
        });
  }

  private boolean isTransactionInProgress = false;

  private void displayFragment(Fragment fragment) {
    if (isTransactionInProgress) {
      return;
    }
    isTransactionInProgress = true;

    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    fragmentTransaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);
    fragmentTransaction.replace(R.id.fragment_container, fragment);
    fragmentTransaction.commit();
    fragmentManager.executePendingTransactions();

    isTransactionInProgress = false;
  }

  private void listFiles(File directory, List<String> fileNames, List<String> filePaths) {
    File[] files = directory.listFiles();
    if (files != null) {
      for (File file : files) {
        fileNames.add(file.getName());
        filePaths.add(file.getPath());
      }
    }
  }

  public String OpenFile(String filename) throws IOException {
    if (!new File(filename).exists()) {
      return "";
    }

    BufferedReader reader = new BufferedReader(new FileReader(filename));
    StringBuilder buf = new StringBuilder();
    String line;
    while ((line = reader.readLine()) != null) buf.append(line).append("\n");
    if (buf.length() > 1) buf.setLength(buf.length() - 1);
    return buf.toString();
  }

  public void write(String path, String cs) {
    try {
      FileOutputStream fos = new FileOutputStream(path);
      fos.write(cs.getBytes());
      fos.flush();
      fos.close();
    } catch (Exception e) {
      YanDialog.show(MainActivity.this, "error", e.getMessage());
      throw new RuntimeException(e);
    }
  }

  public boolean deleteDirectory(File directory) {

    if (directory.isDirectory()) {

      // 获取文件夹内所有文件和文件夹

      File[] files = directory.listFiles();

      if (files != null) { // 有些 JVMs 对空文件夹返回 null

        for (File file : files) {

          // 递归删除每个文件或文件夹

          deleteDirectory(file);
        }
      }
    }

    // 删除文件夹本身

    return directory.delete();
  }

  public static boolean renameDirectory(File currentDir, String newName) {
    // 检查当前文件夹是否存在
    if (!currentDir.exists()) {
      System.out.println("文件夹不存在");
      return false;
    }

    // 检查新名称是否有效
    File newDir = new File(currentDir, newName);
    if (newDir.exists()) {
      System.out.println("新文件夹名称已存在");
      return false;
    }

    // 执行重命名操作
    return currentDir.renameTo(newDir);
  }

  private void addFileToUI(String fileName) {
    boolean isequal = false;
    if (AllPath.size() != 0) {
      for (String ss : AllPath) {
        if (fileName.equals(ss)) {
          isequal = true;
          break;
        }
      }
    }
    if (isequal) {
      for (int i = 0; i <= fragments.size() - 1; ++i) {
        if (AllPath.get(i).equals(fileName)) {
          viewPager2.setCurrentItem(i);
        }
      }
      isequal = false;
    } else {
      AllPath.add(fileName);
      // 创建新的 Fragment
      SharedPreferences sps = getSharedPreferences("OpenList", Context.MODE_PRIVATE);
      SharedPreferences.Editor ed = sps.edit();
      ed.putString(fileName, fileName);
      ed.commit();
      FileContentFragment fragment = FileContentFragment.newInstance();
      // 将文件名传递给 Fragment
      fragment.setFileName(fileName);

      FragmentStateAdapter adapter = (FragmentStateAdapter) viewPager2.getAdapter();
      if (adapter == null) {
        adapter =
            new FragmentStateAdapter(this) {
              @NonNull
              @Override
              public FileContentFragment createFragment(int position) {
                return (FileContentFragment) fragments.get(position);
              }

              @Override
              public int getItemCount() {
                return fragments.size();
              }
            };
        viewPager2.setAdapter(adapter);
      } else {
        adapter.notifyDataSetChanged();
      }

      // 添加到列表并更新 TabLayout
      fragments.add(fragment);
      new TabLayoutMediator(
              tabLayout,
              viewPager2,
              (tab, position) -> {

                // 设置标签文本为文件名

                tab.setText(fragments.get(position).getFileName());
              })
          .attach();
    }
    viewPager2.setCurrentItem(fragments.size() - 1);
  }

  private void removeTabAndFragment(int position) {
    fragments.remove(position);
    SharedPreferences sps = getSharedPreferences("OpenList", Context.MODE_PRIVATE);
    SharedPreferences.Editor ed = sps.edit();
    ed.remove(AllPath.get(position));
    ed.commit();
    AllPath.remove(position);

    FragmentStateAdapter adapter =
        new FragmentStateAdapter(this) {
          @NonNull
          @Override
          public FileContentFragment createFragment(int position) {
            return (FileContentFragment) fragments.get(position);
          }

          @Override
          public int getItemCount() {
            return fragments.size();
          }
        };
    viewPager2.setAdapter(adapter);
    new TabLayoutMediator(
            tabLayout,
            viewPager2,
            (tab, newPosition) -> {
              // 设置标签文本为文件名
              tab.setText(fragments.get(newPosition).getFileName());
            })
        .attach();
  }

  private void showCustomDialog(final Context context, final String path, int type) {
    // 获取布局文件
    LayoutInflater inflater = LayoutInflater.from(context);
    View dialogView = inflater.inflate(R.layout.custom_dialog_layout, null);

    // 获取编辑框
    final EditText editText = dialogView.findViewById(R.id.edit_text);

    // 创建提示框
    AlertDialog.Builder builder = new AlertDialog.Builder(context);
    builder.setTitle("请输入脚本名字");
    builder.setView(dialogView);
    builder.setPositiveButton(
        "确定",
        new DialogInterface.OnClickListener() {

          @Override
          public void onClick(DialogInterface dialog, int which) {
            // 在这里处理用户点击确定按钮的逻辑
            String inputText = editText.getText().toString();
            File file = new File(path + "/" + inputText);
            try {
              if (type == 1) {
                file.createNewFile();
                addFileToUI(path + "/" + inputText);
              } else {
                if (!file.exists()) {
                  file.mkdirs();
                }
              }
              YanDialog.show(context, "", "创建成功!");
              setList();
            } catch (Exception e) {
              YanDialog.show(MainActivity.this, "error", e.getMessage());
            }
          }
        });
    builder.setNegativeButton(
        "取消",
        new DialogInterface.OnClickListener() {
          @Override
          public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        });

    AlertDialog dialog = builder.create();
    dialog.show();
  }

  public List<String> getList(String filename) {

    SharedPreferences sharedPreferences = getSharedPreferences(filename, Context.MODE_PRIVATE);

    Map<String, ?> allEntries = sharedPreferences.getAll();
    Set<String> keys = allEntries.keySet();

    List<String> keyValueList = new ArrayList<>();
    for (String key : keys) {
      String value = sharedPreferences.getString(key, null); // 如果是其他类型的值，请使用相应的方法
      keyValueList.add(value);
    }
    return keyValueList;
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    this.binding = null;
  }

  @Override
  public void onRequestPermissionsResult(
      int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == 1) {
      if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
        Log.d("Permission", "Permission granted");
      } else {
        Log.d("Permission", "Permission denied");
      }
    }
    if (requestCode == 1) {

      if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

        // 权限被授予，可以执行读取操作

      } else {

        // 权限被拒绝，可以提示用户或进行其他操作

      }

    } else if (requestCode == 1) {

      if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

        // 权限被授予，可以执行写入操作

      } else {

        // 权限被拒绝，可以提示用户或进行其他操作

      }
    }
  }

  PopupMenu filepopupMenu;

  @Override
  public void onClick(View arg0) {
    int id = arg0.getId();
    if (id == R.id.showTab) {
      drawerLayout.openDrawer(GravityCompat.START);
    } else if (id == R.id.menu) {
      popo.show();
    } else if (id == R.id.save) {
      filepopupMenu = new PopupMenu(MainActivity.this, arg0);
      Menu filemen = filepopupMenu.getMenu();
      filemen.add(0, 0, 0, "新建文件").setIcon(R.drawable.createfile);
      filemen.add(0, 1, 0, "保存当前").setIcon(R.drawable.save);
      filemen.add(0, 2, 0, "保存所有").setIcon(R.drawable.save);
      filepopupMenu.setOnMenuItemClickListener(
          new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
              int menuId = menuItem.getItemId();
              switch (menuId) {
                case 0:
                  showCustomDialog(MainActivity.this, "/sdcard/OpenLua/", 1);
                  break;
                case 1:
                  write(
                      AllPath.get(pager_choice),
                      fragments.get(pager_choice).edit.getText().toString());
                  YanToast.show(MainActivity.this, "Succeed");
                  break;
                case 2:
                  for (int i = 0; i <= AllPath.size() - 1; i++) {
                    write(AllPath.get(i), fragments.get(i).edit.getText().toString());
                  }
                  YanToast.show(MainActivity.this, "Succeed");
                  break;
              }
              return false;
            }
          });
      filepopupMenu.show();
    } else if (id == R.id.redo) {
      fragments.get(pager_choice).edit.redo();
    } else if (id == R.id.undo) {
      fragments.get(pager_choice).edit.undo();
    } else if (id == R.id.run) {
      if (!drawerLayout.isDrawerOpen(Gravity.START)) {
        LoadingDialog loadingDialog =
            new LoadingDialog.Builder(MainActivity.this).setMessage("正在加载...").create();
        loadingDialog.show();
        ThreadManager.runOnMainThread(
            new Runnable() {
              @Override
              public void run() {

                try {
                  // 显示加载对话框
                  final Globals globals = JsePlatform.standardGlobals();
                  BaseLib baselib = new BaseLib();
                  YanLib yanlib = new YanLib();
                  yanlib.c = MainActivity.this;
                  baselib.c = MainActivity.this;
                  globals.load(baselib);
                  globals.load(yanlib);
                  globals.load(new PackageLib());
                  globals.load(new Bit32Lib());
                  globals.load(new TableLib());
                  globals.load(new StringLib());
                  globals.load(new CoroutineLib());
                  globals.load(new JseMathLib());
                  globals.load(new JseIoLib());
                  globals.load(new JseOsLib());
                  globals.load(new LuajavaLib());
                  globals.load(new DebugLib());
                  globals.load(new Utf8Lib());
                  LoadState.install(globals);
                  LuaC.install(globals);
                  globals.load(fragments.get(pager_choice).edit.getText().toString()).call();

                  if (!(baselib.str).toString().equals("")) {
                    ThreadManager.runOnUiThread(
                        new Runnable() {
                          @Override
                          public void run() {
                            Intent i = new Intent(MainActivity.this, RunResults.class);
                            // i.putExtra("result", baselib.str.toString());
                            write("/sdcard/Ylua/output.txt", baselib.str.toString());
                            startActivity(i);
                          }
                        });
                  }
                  loadingDialog.dismiss();
                  // 线程执行完毕后关闭加载对话框

                } catch (LuaError e) {
                  Intent i = new Intent(MainActivity.this, RunResults.class);
                  // i.putExtra("result", e.getMessage());
                  write("/sdcard/Ylua/output.txt", e.getMessage());
                  startActivity(i);
                  // 出错时也关闭加载对话框
                  loadingDialog.dismiss();
                }
              }
            });
      }
    } else if (id == R.id.search_options) {
      searchMenu.show();
      // startActivity(new Intent(this, LspTestJavaActivity.class));
    } else if (id == R.id.btn_goto_prev) {
      gotoPrev();
    } else if (id == R.id.btn_goto_next) {
      gotoNext();
    }
  }
}
