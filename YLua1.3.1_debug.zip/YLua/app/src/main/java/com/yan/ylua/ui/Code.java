package com.yan.ylua.ui;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import com.yan.ylua.R;

public class Code extends Fragment {
  @Override
  public View onCreateView(LayoutInflater arg0, ViewGroup arg1, Bundle arg2) {
    // TODO: Implement this method
    return arg0.inflate(R.layout.code, arg1, false);
  }
}
