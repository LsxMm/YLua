package com.yan.ylua;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.yan.ylua.TextMateLanguage.TextMateLanguage;
import com.yan.ylua.Tools.YanDialog;
import com.yan.ylua.Tools.ThreadManager;
import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme;
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel;
import io.github.rosemoe.sora.langs.textmate.registry.provider.AssetsFileResolver;
import io.github.rosemoe.sora.widget.CodeEditor;
import io.github.rosemoe.sora.widget.SymbolInputView;
import io.github.rosemoe.sora.widget.schemes.SchemeGitHub;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import org.eclipse.tm4e.core.registry.IThemeSource;

public class FileContentFragment extends Fragment {

  public String fileName;
  public CodeEditor edit;
  SymbolInputView sym;
  LinearLayout searchPanel;
  EditText search, replace;
  String[] keyword =
      new String[] {
        "and",
        "or",
        "if",
        "break",
        "else",
        "do",
        "elseif",
        "end",
        "for",
        "function",
        "local",
        "in",
        "false",
        "true",
        "while",
        "not",
        "nil",
        "return",
        "then",
        "goto",
        "repeat",
        "until",
        "string",
        "io",
        // os
        "os",
        // debug
        "debug",
        // utf8
        "utf8",
        // table
        "table",
        // math
        "math",
        // bit32
        "bit32",
        // luajava
        "luajava",

        // text
        "pcall",
        "load",
        "tostring",
        "tonumber",
        "error",
        "loadfile",
        "setmetatable",
        "pairs",
        "next",
        "assert",
        "rawlen",
        "ipairs",
        "xpcall",
        "rawequal",
        "getmetatable",
        "rawset",
        "type",
        "select",
        "dofile",
        "print",
        // gg
        "gg"
      };

  public static FileContentFragment newInstance() {
    return new FileContentFragment();
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment, container, false);
    edit = view.findViewById(R.id.activity_mainio_github_rosemoe_sora_widget_CodeEditor);
    sym = view.findViewById(R.id.symbol_input);
    searchPanel = view.findViewById(R.id.search_panel);
    search = view.findViewById(R.id.search_editor);
    replace = view.findViewById(R.id.replace_editor);
    sym.bindEditor(edit);
    SharedPreferences sps = getActivity().getSharedPreferences("EditorSet", Context.MODE_PRIVATE);
    String[] symbols =
        new String[] {
          "->", "Fun", "{", "}", "(", ")", ",", ".", ";", "\"", "?", "+", "-", "*", "/", "=", "'",
          "[", "]", ":"
        };
    String[] equivalents =
        new String[] {
          "\t",
          "function",
          "{}",
          "}",
          "()",
          ")",
          ",",
          ".",
          ";",
          "\"",
          "?",
          "+",
          "-",
          "*",
          "/",
          "=",
          "'",
          "[]",
          "]",
          ":"
        };
    sym.addSymbols(symbols, equivalents);
    FileProviderRegistry.getInstance()
        .addFileProvider(
            new AssetsFileResolver(
                getActivity().getAssets() // 使用应用上下文
                ));
    var themeRegistry = ThemeRegistry.getInstance();
    var name = "darcula"; // 主题名称
    var themeAssetsPath = "textmate/" + name + ".json";
    var model =
        new ThemeModel(
            IThemeSource.fromInputStream(
                FileProviderRegistry.getInstance().tryGetInputStream(themeAssetsPath),
                themeAssetsPath,
                null),
            name);
    var model2 =
        new ThemeModel(
            IThemeSource.fromInputStream(
                FileProviderRegistry.getInstance().tryGetInputStream("textmate/quietlight.json"),
                "textmate/quietlight.json",
                null),
            name);
    // 如果主题是适用于暗色模式的，请额外添加以下内容

    model.setDark(true);
    try {
      int Scheme = sps.getInt("Scheme", 0);

      switch (Scheme) {
        case 1:
          themeRegistry.loadTheme(model);
          edit.setColorScheme(new SchemeGitHub());
          sym.setTextColor(0xffffffff);
          sym.setBackgroundColor(0xff1b1b1b);
          break;
        case 0:
          themeRegistry.loadTheme(model2);
          ThemeRegistry.getInstance().setTheme("quietlight");
          sym.setTextColor(0xff000000);
          sym.setBackgroundColor(0xffffffff);
          break;
      }

      GrammarRegistry.getInstance().loadGrammars("textmate/languages.json");
      var sch = TextMateColorScheme.create(ThemeRegistry.getInstance());
      edit.setColorScheme(sch);

      //edit.setColorScheme(new YluaScheme());

      var languageScopeName = "source.lua"; // 您目标语言的作用域名称

      var language = TextMateLanguage.create(languageScopeName, true /* true表示启用自动补全 */);
      language.setCompleterKeywords(keyword);
      // language.setCompleterKeywords(keyword);
      edit.setEditorLanguage(language);
            //edit.setEditorLanguage(new LuaLanguage());
      edit.setNonPrintablePaintingFlags(
          CodeEditor.FLAG_DRAW_WHITESPACE_LEADING
              | CodeEditor.FLAG_DRAW_LINE_SEPARATOR
              | CodeEditor.FLAG_DRAW_WHITESPACE_IN_SELECTION);
      edit.setWordwrap(sps.getBoolean("Wordwarp", true));
      edit.setLineNumberEnabled(sps.getBoolean("linenumber", true));
      edit.setPinLineNumber(sps.getBoolean("pin", false));
            edit.setBlockLineEnabled(true);
            
      /*List<String> colors = new ArrayList<>();
      for (int i = 1; i <= 64; i++) {

        int ss = edit.getColorScheme().getColor(i);
        colors.add(i + "=0x" + String.format("%x", ss));
      }*/
      // copyTextToClipboard(colors.toString());

    } catch (Exception e) {
      YanDialog.show(getActivity(), "", e.getMessage());
    }
    ThreadManager.runOnMainThread(
        new Runnable() {
          @Override
          public void run() {
            ThreadManager.runOnUiThread(
                new Runnable() {
                  @Override
                  public void run() {
                    try {
                      edit.setText(OpenFile(fileName));
                    } catch (Exception e) {
                    }
                  }
                });
          }
        });

    return view;
  }

  // 假设这是在一个Activity中

  public void copyTextToClipboard(String text) {
    // 获取剪贴板管理器
    ClipboardManager clipboard =
        (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);

    // 创建ClipData对象，这里的"Label"可以是任何描述性文本，"text"是你想要复制的内容
    ClipData clip = ClipData.newPlainText("Label", text);

    // 将ClipData内容设置到剪贴板
    clipboard.setPrimaryClip(clip);
  }

  private static int getLineNumber(String text, int index) {
    int lineNumber = 1;
    int lineStartIndex = 0;
    while (index > lineStartIndex && lineStartIndex < text.length()) {
      if (text.charAt(lineStartIndex) == '\n') {
        lineNumber++;
      }
      lineStartIndex++;
    }
    return lineNumber;
  }

  public String getFileName() {
    return new File(fileName).getName();
  }

  public String OpenFile(String filename) throws IOException {
    if (!new File(filename).exists()) {
      return "";
    }

    BufferedReader reader = new BufferedReader(new FileReader(filename));
    StringBuilder buf = new StringBuilder();
    String line;
    while ((line = reader.readLine()) != null) buf.append(line).append("\n");
    if (buf.length() > 1) buf.setLength(buf.length() - 1);
    return buf.toString();
  }

  public void redo() {
    edit.redo();
  }

  public boolean canredo() {
    return edit.canRedo();
  }

  public void undo() {
    edit.undo();
  }

  public boolean canundo() {
    return edit.canUndo();
  }

  public void showSearch() {
    if (searchPanel.getVisibility() == View.GONE) {
      searchPanel.setVisibility(View.VISIBLE);

    } else {
      searchPanel.setVisibility(View.GONE);
    }
  }

  public void gotoNext() {
    try {
      edit.getSearcher().gotoNext();
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void gotoLast() {
    try {
      edit.getSearcher().gotoPrevious();
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void replace() {
    try {
      edit.getSearcher().replaceThis(replace.getText().toString());
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void replaceAll() {
    try {
      // binding.editor.searcher.replaceAll(binding.replaceEditor.text.toString())
    } catch (IllegalStateException e) {
      e.printStackTrace();
    }
  }

  public void showSearchOptions() {
    // searchMenu.show();
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    // 这里可以根据需要加载文件内容到 EditText
  }
}
