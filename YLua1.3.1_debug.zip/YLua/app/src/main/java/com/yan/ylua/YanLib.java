package com.yan.ylua;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Context;
import com.yan.ylua.Tools.UnluacTool;
import com.yan.ylua.Tools.YanDialog;
import com.yan.ylua.Tools.YanToast;
import com.yan.ylua.Tools.FileTool;
import com.yan.ylua.Tools.NetworkRequestUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.OneArgFunction;
import org.luaj.vm2.lib.ThreeArgFunction;
import org.luaj.vm2.lib.TwoArgFunction;
import org.luaj.vm2.lib.jse.JsePlatform;

public class YanLib extends TwoArgFunction {
  public Context c;
  public int s;
  public String fi;

  @Override
  public LuaValue call(LuaValue arg1, LuaValue env) {
    LuaValue YT2 = tableOf();
    LuaValue File = tableOf();
    File.set("mkdirs", new mkdir());
    File.set("deletedir", new deletedir());
    File.set("filelist", new filelist());
    YT2.set("choice", new choice());
    YT2.set("toast", new toast());
    YT2.set("alert", new alert());
    YT2.set("exec", new exec());
    YT2.set("thread", new thread());
    YT2.set("makeRequest", new makeRequstion());
    YT2.set("unluac", new unluac());
    YT2.set("unluac2", new unluac2());
    YT2.set("unluac3", new unluac3());
    YT2.set("loadjs", new loadjs());
    env.set("gg", YT2);
    env.get("gg").set("File", File);
    env.get("package").get("loaded").set("gg", YT2);
    env.get("package").get("loaded").get("gg").set("File", File);
    return YT2;
  }

  class choice extends ThreeArgFunction
      implements DialogInterface.OnClickListener, DialogInterface.OnDismissListener {

    private Semaphore semaphore = new Semaphore(0);
    private int s = 0;

    @Override
    public void onClick(DialogInterface dialog, int which) {
      s = which + 1;
      semaphore.release();
      dismiss(dialog);
    }

    @Override
    public LuaValue call(LuaValue arg1, LuaValue arg2, final LuaValue arg3) {
      final String[] sh1 = new String[arg1.length()];
      for (int k = 0; k < arg1.length(); k++) {
        sh1[k] = arg1.get(k + 1).toString();
      }

      new Handler(Looper.getMainLooper())
          .post(
              new Runnable() {
                @Override
                public void run() {
                  AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(c);
                  if (!arg3.toString().equals("")) {
                    dialogBuilder.setTitle(arg3.toString());
                  } else {
                    dialogBuilder.setTitle("OpenLua");
                  }
                  dialogBuilder.setItems(sh1, choice.this);
                  final AlertDialog dialog = dialogBuilder.create();
                  dialog.setOnDismissListener(choice.this); // 设置对话框的消失监听
                  dialog.show();
                }
              });

      try {
        semaphore.acquire();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      if (s != 0) {
        return LuaValue.valueOf(s);
      } else {
        return LuaValue.NIL;
      }
    }

    @Override
    public void onDismiss(DialogInterface dialog) { // 实现对话框消失的监听方法
      semaphore.release(); // 释放信号量，通知其他线程继续
    }

    public void dismiss(DialogInterface dialogInterface) {
      if (dialogInterface == null) {
        throw new NullPointerException();
      }
      new Handler(Looper.getMainLooper())
          .post(
              new Runnable() {
                @Override
                public void run() {
                  try {
                    dialogInterface.dismiss();
                  } catch (Throwable th) {

                  }
                }
              });
    }
  }

  class unluac extends TwoArgFunction {
    @Override
    public LuaValue call(LuaValue arg1, LuaValue arg2) {
      boolean is = false;
      try {
        UnluacTool.decompile(arg1.toString(), arg2.toString());
        is = true;
      } catch (Exception err) {
        YanDialog.show(c, "err", err.getMessage());
      }
      return LuaValue.valueOf(is);
    }
  }

  class unluac2 extends TwoArgFunction {
    @Override
    public LuaValue call(LuaValue arg1, LuaValue arg2) {
      boolean is = false;
      try {
        UnluacTool.disassemble(arg1.toString(), arg2.toString());
        is = true;
      } catch (Exception err) {
        YanDialog.show(c, "err", err.getMessage());
      }
      return LuaValue.valueOf(is);
    }
  }

  class unluac3 extends TwoArgFunction {
    @Override
    public LuaValue call(LuaValue arg1, LuaValue arg2) {
      boolean is = false;
      try {
        UnluacTool.assemble(arg1.toString(), arg2.toString());
        is = true;
      } catch (Exception err) {
        YanDialog.show(c, "err", err.getMessage());
      }
      return LuaValue.valueOf(is);
    }
  }

  class exec extends OneArgFunction {

    @Override
    public LuaValue call(LuaValue arg) {
      execu(arg.checkstring().toString());
      return null;
    }

    public void execu(String shellString) {
      BufferedReader reader = null;
      try {
        Process process = Runtime.getRuntime().exec(shellString);

        reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line = null;
        StringBuffer show = new StringBuffer();
        while ((line = reader.readLine()) != null) {
          // System.out.println("mac@wxw %  " + line);
          show.append(line);
        }
        YanDialog.show(c, "exec运行成功", show.toString());
      } catch (Throwable e) {
        YanDialog.show(c, "exec运行失败", e.getMessage());
      }
    }
  }

  class makeRequstion extends ThreeArgFunction {
    String ret = "";
    private Semaphore semaphore = new Semaphore(0);

    @Override
    public LuaValue call(LuaValue arg1, LuaValue arg2, LuaValue arg3) {
      String url = arg1.tojstring();
      String requst = arg2.tojstring();
      String str = arg3.tojstring();
      new Handler(Looper.getMainLooper())
          .post(
              new Runnable() {
                @Override
                public void run() {
                  if (!requst.equals("") && requst.equals("post")) {
                    new NetworkRequestUtils()
                        .sendPostRequest(
                            url,
                            str,
                            new NetworkRequestUtils.OnResponseListener() {
                              @Override
                              public void onError(String error) {
                                ret = error.toString();
                                semaphore.release();
                              }

                              @Override
                              public void onResponse(JSONObject jsonObject) {
                                ret = jsonObject.toString();
                                semaphore.release();
                              }

                              @Override
                              public void onResponse(String text) {
                                ret = text;
                                semaphore.release();
                              }
                            });
                  } else {
                    new NetworkRequestUtils()
                        .sendGetRequest(
                            url,
                            new NetworkRequestUtils.OnResponseListener() {
                              @Override
                              public void onError(String error) {
                                ret = error.toString();
                                semaphore.release();
                              }

                              @Override
                              public void onResponse(JSONObject jsonObject) {
                                ret = jsonObject.toString();
                                semaphore.release();
                              }

                              @Override
                              public void onResponse(String text) {
                                ret = text;
                                semaphore.release();
                              }
                            });
                  }
                }
              });
      try {
        semaphore.acquire();
      } catch (Exception err) {

      }
      return LuaValue.valueOf(ret);
    }
  }

  class toast extends OneArgFunction {

    @Override
    public LuaValue call(LuaValue arg) {
      ((MainActivity) c)
          .runOnUiThread(
              () -> {
                YanToast.show(c, arg.toString());
              });
      return null;
    }
  }

  class deletedir extends OneArgFunction {

    @Override
    public LuaValue call(LuaValue arg) {
      return LuaValue.valueOf((new FileTool().deleteDir(new File(arg.checkjstring().toString()))));
    }
  }

  class filelist extends OneArgFunction {

    @Override
    public LuaValue call(LuaValue arg) {
      FileTool f = new FileTool();
      String[] list = f.FileList(arg.toString());
      // System.out.println(list);
      LuaValue tab = tableOf();
      for (int i = 0; i < list.length; i++) {
        if ((new File(arg.toString() + list[i])).isFile()) {
          tab.set(i + 1, list[i]);
        }
        // System.out.println(i);
      }
      // System.out.println(tab);
      return tab;
    }
  }

  class loadjs extends OneArgFunction {
    @Override
    public LuaValue call(LuaValue arg) {
      String script = arg.toString();
      return LuaValue.valueOf(script);
    }
  }

  class thread extends OneArgFunction {

    @Override
    public LuaValue call(LuaValue arg) {
      if (!arg.isfunction()) {
        return LuaValue.NIL;
      }
      new Thread(
              () -> {
                // 创建 Lua 全局环境
                Globals globals = JsePlatform.standardGlobals();

                // 调用 Lua 函数
                arg.call();
              })
          .start();
      return LuaValue.NIL;
    }
  }

  class mkdir extends OneArgFunction {
    @Override
    public LuaValue call(LuaValue arg) {
      return LuaValue.valueOf(new FileTool().mkdirs(arg.toString()));
    }
  }

  class alert extends OneArgFunction {

    @Override
    public LuaValue call(LuaValue arg1) {
      ((MainActivity) c)
          .runOnUiThread(
              () -> {
                YanDialog.show(c, "OpenLuaY", arg1.toString());
              });
      return null;
    }
  }

  static void waitNotify(Object obj) {
    try {
      obj.wait();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new LuaError(e);
    }
  }
}
