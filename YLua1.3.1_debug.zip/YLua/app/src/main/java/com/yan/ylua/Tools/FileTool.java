package com.yan.ylua.Tools;

import java.io.File;
import java.io.FileFilter;

public class FileTool {
  public static boolean deleteDir(File dir) {
    if (dir.isDirectory()) {
      String[] children = dir.list();
      for (int i = 0; i < children.length; i++) {
        boolean success = deleteDir(new File(dir, children[i]));
        if (!success) {
          return false;
        }
      }
    }
    if (dir.delete()) {
      System.out.println("目录已被删除！");
      return true;
    } else {
      System.out.println("目录删除失败！");
      return false;
    }
  }

  public String[] FileList(String Str) {
    File dir = new File(Str);
    String[] children = dir.list();
    return children;
  }

  public boolean mkdirs(String str) {
    File file = new File(str);
    boolean ic = false;
    file.mkdir();
    if (file.isDirectory()) {
      ic = true;
    }
    return ic;
  }

  public static String getFileType(String filePath) {
    File file = new File(filePath);
    String fileName = file.getName();
    int lastIndexOfDot = fileName.lastIndexOf('.');
    if (lastIndexOfDot > 0) {
      String extension = fileName.substring(lastIndexOfDot + 1).toLowerCase();
      return extension;
    } else {
      return "No Extension";
    }
  }
}
