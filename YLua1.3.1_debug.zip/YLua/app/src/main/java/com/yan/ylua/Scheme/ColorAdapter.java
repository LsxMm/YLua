package com.yan.ylua.Scheme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import com.yan.ylua.R;

public class ColorAdapter extends BaseAdapter {
  private Context mContext;
  private List<String> mDataset;
  private List<Integer> mColor;
  private OnItemClickListener mListener;

  public ColorAdapter(Context context, List<String> dataset, List<Integer> color) {
    mContext = context;
    mDataset = dataset;
    mColor = color;
  }

  @Override
  public int getCount() {
    return mDataset.size();
  }

  @Override
  public Object getItem(int position) {
    return mColor.get(position);
  }

  @Override
  public long getItemId(int position) {
    return position;
  }

  public void setPosition(int position, int color) {
    mColor.set(position, color);
  }

  public void setOnItemClickListener(OnItemClickListener listener) {
    mListener = listener;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    // Get the data item for this adapter is representing
    String item = mDataset.get(position);

    // Create view if it does not exist
    if (convertView == null) {
      convertView = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);
    }

    // Look up view for data population
    TextView tvMain = (TextView) convertView.findViewById(R.id.textViewMain);
    TextView tvDetail = (TextView) convertView.findViewById(R.id.textViewDetail);

    // Populate the data into the template view using the data object
    tvMain.setText(item);
    tvDetail.setText("0x" + String.format("%X", mColor.get(position))); // Assuming this is static
    tvDetail.setBackgroundColor(mColor.get(position));
    convertView.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View arg0) {
            mListener.OnItemClick(item, position);
          }
        });
    // Return the completed view to render on screen
    return convertView;
  }

  public interface OnItemClickListener {
    void OnItemClick(String type, int position);
  }
}
