package com.yan.ylua;

import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.yan.ylua.Tools.ThreadManager;
import io.github.rosemoe.sora.widget.CodeEditor;
import java.io.IOException;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;

public class RunResults extends AppCompatActivity {
  CodeEditor re;
  String code;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.layout_run_results);
    try {
      code = OpenFile("/sdcard/Ylua/output.txt");
    } catch (IOException e) {
    }
    re = findViewById(R.id.results);
    re.setLineNumberEnabled(false);
    re.setEditable(false);
    re.setWordwrap(true);
    ThreadManager.runOnMainThread(
        new Runnable() {
          @Override
          public void run() {
            ThreadManager.runOnUiThread(
                new Runnable() {
                  @Override
                  public void run() {
                    re.setText(code);
                  }
                });
          }
        });
  }

  public String OpenFile(String filename) throws IOException {
    if (!new File(filename).exists()) {
      return "";
    }

    BufferedReader reader = new BufferedReader(new FileReader(filename));
    StringBuilder buf = new StringBuilder();
    String line;
    while ((line = reader.readLine()) != null) buf.append(line).append("\n");
    if (buf.length() > 1) buf.setLength(buf.length() - 1);
    return buf.toString();
  }
}
