package com.yan.ylua;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.util.List;

public class FileListAdapter extends BaseAdapter {
  private Context mContext;
  private List<String> mTopTexts;
  private List<String> mPath;
  private OnItemClickListener mListener;
  private OnItemLongClickListener mLongListener;

  public FileListAdapter(Context context, List<String> topTexts, List<String> path) {
    mContext = context;
    mTopTexts = topTexts;
    mPath = path;
  }

  public void setOnItemClickListener(OnItemClickListener listener) {
    mListener = listener;
  }

  public void setOnItemLongClickListener(OnItemLongClickListener listener) {
    mLongListener = listener;
  }

  @Override
  public int getCount() {
    return mTopTexts.size();
  }

  @Override
  public Object getItem(int position) {
    return null;
  }

  @Override
  public long getItemId(int position) {
    return 0;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    ViewHolder holder;
    if (convertView == null) {
      convertView = LayoutInflater.from(mContext).inflate(R.layout.openlua_filelist, parent, false);
      holder = new ViewHolder();
      holder.topTextView = convertView.findViewById(R.id.topTextView);
      holder.image = convertView.findViewById(R.id.image);
      convertView.setTag(holder);
    } else {
      holder = (ViewHolder) convertView.getTag();
    }

    holder.topTextView.setText(mTopTexts.get(position));
    SharedPreferences sps = mContext.getSharedPreferences("EditorSet", Context.MODE_PRIVATE);
    boolean isDirectory = new File(mPath.get(position)).isDirectory();
    int scheme = sps.getInt("Scheme", 0);
    int textColor;
    int imageResource;
    if (position == 0) {
      if (scheme == 0) {
        imageResource = R.drawable.folder;
        textColor = 0xff000000;
      } else {
        imageResource = R.drawable.folder_white;
        textColor = 0xffffffff;
      }
    } else {
      if (scheme == 0) {
        imageResource = isDirectory ? R.drawable.folder : R.drawable.code;
        textColor = 0xff000000;
      } else {
        imageResource = isDirectory ? R.drawable.folder_white : R.drawable.code_white;
        textColor = 0xffffffff;
      }
    }
    holder.image.setBackgroundResource(imageResource);
    holder.topTextView.setTextColor(textColor);

    // 设置点击效果
    final int finalPosition = position;
    convertView.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            if (mListener != null) {
              mListener.onItemClick(mTopTexts.get(finalPosition), finalPosition);
            }
          }
        });

    // 设置长按事件
    convertView.setOnLongClickListener(
        new View.OnLongClickListener() {
          @Override
          public boolean onLongClick(View v) {
            if (mLongListener != null) {
              mLongListener.onItemLongClick(mTopTexts.get(finalPosition), finalPosition, v);
              return true;
            }
            return false;
          }
        });

    return convertView;
  }

  public class ViewHolder {
    TextView topTextView;
    ImageView image;
  }

  public interface OnItemClickListener {
    void onItemClick(String topText, int position);
  }

  public interface OnItemLongClickListener {
    void onItemLongClick(String topText, int position, View v);
  }
}
