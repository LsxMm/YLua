package com.yan.ylua.Tools;

import java.io.File;
import java.io.IOException;
import unluac.Configuration;
import unluac.Main;
import unluac.decompile.Decompiler;
import unluac.decompile.Output;
import unluac.decompile.FileOutputProvider;

import java.io.File;
import java.io.IOException;
import unluac.Configuration;
import unluac.Main;

public class UnluacTool {

    public static void decompile(String inputFilePath, String outputFilePath) throws IOException {
        Configuration config = new Configuration();
        Main.decompile(inputFilePath, outputFilePath, config);
    }

    public static void assemble(String inputFilePath, String outputFilePath) throws IOException {
        try {
            Main.assemble(inputFilePath, outputFilePath);
        } catch (Exception e) {
            throw new IOException("汇编失败：" + e.getMessage());
        }
    }

    public static void disassemble(String inputFilePath, String outputFilePath) throws IOException {
        try {
            Main.disassemble(inputFilePath, outputFilePath);
        } catch (Exception e) {
            throw new IOException("反汇编失败：" + e.getMessage());
        }
    }
}

